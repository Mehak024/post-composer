# Post Composer

A multi-platform social media post composer. Write once, tailor it to
platform-specific character limits, attach media, schedule it for later
(or publish immediately), and watch it move from **Scheduled → Published**
automatically — even if you close the tab.

## Features

- **Platform selection** — Twitter/X, Threads, Pinterest, Instagram, Quora,
  and Facebook, each with its own character limit and live preview style.
- **Title & Description** — both required, with live character counters.
- **Media upload** — optional image/video attachment with preview and remove.
- **Scheduling (optional)** — pick a future date/time, or leave it blank to
  publish immediately. Past dates are blocked.
- **Real-time validation** — required fields, per-platform character
  limits, and schedule are all checked live; Publish is disabled until
  everything passes.
- **Drafts** — save/restore/clear a full snapshot (title, description,
  platforms, schedule, and a small image preview) to `localStorage`.
- **A backend scheduler that actually runs** — scheduling a post doesn't
  just store a date. The Express backend polls for due posts every few
  seconds and flips them from `scheduled` to `published` on its own,
  independent of the browser tab being open. The frontend polls
  `GET /api/posts` and reflects the change live.
- **Live preview** — a rough per-platform preview of how the post (and any
  attached media) will look.

## Project layout

```
post composer/
├── client/                 React 18 + Vite + Tailwind CSS
│   └── src/
│       ├── components/     Presentational + feature components
│       ├── context/        React Context providers (platform, post, media,
│       │                   schedule, posts feed)
│       ├── hooks/          Thin hooks wrapping each context
│       ├── data/           Platform definitions, preview config
│       ├── utils/          Validation, text stats, storage helpers
│       └── pages/          Composer.jsx — the single page
│
└── server/                 Node.js + Express REST API
    ├── routes/             /api/publish, /api/posts
    ├── models/              File-backed posts store (data/posts.json)
    ├── services/            Background scheduler
    └── server.js
```

## Getting started

Requires [Node.js](https://nodejs.org/) 18+.

**1. Install dependencies (both apps):**
```bash
cd "post composer/server" && npm install
cd "../client" && npm install
```

**2. Start the backend** (Terminal 1):
```bash
cd "post composer/server"
npm run dev
```
You should see `Server running on http://localhost:5050`.

**3. Start the frontend** (Terminal 2):
```bash
cd "post composer/client"
npm run dev
```
Opens `http://localhost:5173`. The dev server proxies `/api/*` requests to
the backend on port 5050 automatically — no extra config needed.

**4. Try scheduling:**
Fill in Title + Description, select a platform, pick a date/time about
30–60 seconds in the future in Step 5, and publish. Watch the "Your posts"
section at the bottom — it'll show **Scheduled**, then flip to
**Published** on its own within a few seconds of that time arriving, with
no page reload needed.

### Troubleshooting

- **`EADDRINUSE` on port 5000** — older versions of this project defaulted
  to port 5000, which macOS's AirPlay Receiver often claims. The backend
  now defaults to **5050** to avoid this. If you still hit a port
  conflict, create a `.env` file in `server/` (copy `.env.example`) with a
  different `PORT`, and update the proxy target in
  `client/vite.config.js` to match.
- **"Couldn't reach the server"** on Publish — make sure the backend
  (`npm run dev` in `server/`) is running before you click Publish.

## How scheduling actually works

`POST /api/publish` writes the post to a small JSON file
(`server/data/posts.json`, created automatically, and git-ignored) with a
status of `scheduled` or `published` depending on whether a future date
was given. A background interval in `server/services/scheduler.js` checks
that file every 5 seconds and flips any post whose scheduled time has
arrived to `published`. The frontend's `PostsContext` polls
`GET /api/posts` on the same rhythm, so the UI reflects it without any
manual refresh.

This is a real, working scheduler — it does not depend on the browser tab
staying open. It does **not** post to any real social media platform;
"published" here means "the scheduled time arrived," not "posted to
Twitter." See **Limitations** below for what real publishing would need.

## Tech stack

**Frontend:** React 18, Vite, Tailwind CSS, react-icons
**Backend:** Node.js, Express, a file-backed JSON store (no external DB
required to run this project)

## Limitations / what real-world deployment would add

This project demonstrates the full composer UX and a genuinely working
scheduler, but does not post to real social media accounts. Turning it
into something the public could use for real posting would additionally
require:

- **OAuth login for each platform** (Twitter/X API, Meta Graph API for
  Facebook/Instagram, Pinterest API) to post on a user's behalf. Quora has
  no public API for posting, so it couldn't be automated at all.
- **User accounts** and a real database (Postgres/MongoDB) instead of
  `localStorage` and a JSON file.
- **Cloud media storage** (e.g. S3) instead of in-browser object URLs.
- **A production job queue** (e.g. BullMQ + Redis) instead of a simple
  polling interval, for reliability at scale.
- **Hosting** for both the frontend (e.g. Vercel) and a long-running
  backend process (e.g. Render/Railway), plus a real domain and HTTPS.
- Compliance with each platform's developer terms and app-review process.

## License

MIT — see [LICENSE](LICENSE).
