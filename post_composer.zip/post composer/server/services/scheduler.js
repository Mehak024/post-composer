import { getDuePosts, updatePost } from "../models/postsStore.js";

// -----------------------------------------------------------------------
// The actual "real scheduling" piece: a background loop, independent of
// any browser tab being open, that checks every few seconds for posts
// whose scheduledAt has arrived and flips them from "scheduled" to
// "published." The publish itself is still simulated (no real API call
// to Twitter/Instagram/etc.) — but the *timing* is real.
// -----------------------------------------------------------------------

const CHECK_INTERVAL_MS = 5000; // check every 5s — fine for a demo; a
// real deployment would likely use a proper job queue (BullMQ, Agenda,
// etc.) instead of a naive interval, especially across multiple server
// instances.

let intervalHandle = null;

async function checkAndPublishDuePosts() {
  const duePosts = await getDuePosts();

  for (const post of duePosts) {
    await updatePost(post.id, {
      status: "published",
      publishedAt: new Date().toISOString(),
    });
    console.log(
      `[scheduler] Published "${post.title}" (${post.id}) — was scheduled for ${post.scheduledAt}`
    );
  }
}

export function startScheduler() {
  if (intervalHandle) return; // already running

  console.log(`[scheduler] Started — checking for due posts every ${CHECK_INTERVAL_MS / 1000}s`);
  intervalHandle = setInterval(checkAndPublishDuePosts, CHECK_INTERVAL_MS);

  // Also run once immediately on startup, in case posts came due while
  // the server was down.
  checkAndPublishDuePosts();
}

export function stopScheduler() {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
  }
}
