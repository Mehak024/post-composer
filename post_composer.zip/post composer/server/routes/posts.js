import { Router } from "express";
import { getAllPosts } from "../models/postsStore.js";

const router = Router();

router.get("/", async (req, res) => {
  const posts = await getAllPosts();
  res.status(200).json({ success: true, posts });
});

export default router;
