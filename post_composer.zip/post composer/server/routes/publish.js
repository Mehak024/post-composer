import { Router } from "express";
import { addPost } from "../models/postsStore.js";

const router = Router();

// Simulates a REST API for publishing, but with a REAL scheduling path:
// - No scheduledAt (or one that's already due) → published immediately.
// - A future scheduledAt → stored with status "scheduled"; the
//   background scheduler (services/scheduler.js) flips it to
//   "published" on its own once that time arrives, even if nobody's
//   looking at the app.
// Nothing is actually posted to a real social platform — see the
// project README for what that would additionally require.
router.post("/", async (req, res) => {
  const { title, content, platformIds, scheduledAt, media } = req.body ?? {};

  if (!title || !title.trim()) {
    return res.status(400).json({ success: false, message: "Title is required." });
  }

  if (!content || !content.trim()) {
    return res.status(400).json({ success: false, message: "Description is required." });
  }

  if (!Array.isArray(platformIds) || platformIds.length === 0) {
    return res
      .status(400)
      .json({ success: false, message: "Select at least one platform." });
  }

  if (scheduledAt && new Date(scheduledAt).getTime() < Date.now()) {
    return res
      .status(400)
      .json({ success: false, message: "Schedule can't be in the past." });
  }

  const isScheduledForLater =
    Boolean(scheduledAt) && new Date(scheduledAt).getTime() > Date.now();

  const post = {
    id: `post_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    title,
    content,
    platformIds,
    media: media ?? null,
    scheduledAt: scheduledAt || null,
    status: isScheduledForLater ? "scheduled" : "published",
    createdAt: new Date().toISOString(),
    publishedAt: isScheduledForLater ? null : new Date().toISOString(),
  };

  await addPost(post);

  // Simulate a little network/processing latency before responding.
  setTimeout(() => {
    res.status(200).json({
      success: true,
      message: isScheduledForLater
        ? `Post scheduled for ${new Date(scheduledAt).toLocaleString()}.`
        : "Post published successfully.",
      post,
    });
  }, 500);
});

export default router;
