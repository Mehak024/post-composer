import { readFile, writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

// -----------------------------------------------------------------------
// A tiny file-backed "database." A real deployment would swap this for
// Postgres/Mongo, but for a demo/college project, persisting to a JSON
// file is enough to prove scheduling survives across requests (and even
// a server restart) without needing to stand up and configure a real DB.
// -----------------------------------------------------------------------

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "..", "data");
const DATA_FILE = path.join(DATA_DIR, "posts.json");

async function ensureStore() {
  if (!existsSync(DATA_DIR)) {
    await mkdir(DATA_DIR, { recursive: true });
  }
  if (!existsSync(DATA_FILE)) {
    await writeFile(DATA_FILE, "[]", "utf-8");
  }
}

async function readAll() {
  await ensureStore();
  const raw = await readFile(DATA_FILE, "utf-8");
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

async function writeAll(posts) {
  await ensureStore();
  await writeFile(DATA_FILE, JSON.stringify(posts, null, 2), "utf-8");
}

export async function getAllPosts() {
  const posts = await readAll();
  // Newest first — whichever timestamp is most relevant per post.
  return posts.sort(
    (a, b) =>
      new Date(b.scheduledAt || b.createdAt) -
      new Date(a.scheduledAt || a.createdAt)
  );
}

export async function addPost(post) {
  const posts = await readAll();
  posts.push(post);
  await writeAll(posts);
  return post;
}

export async function updatePost(id, updates) {
  const posts = await readAll();
  const index = posts.findIndex((post) => post.id === id);
  if (index === -1) return null;

  posts[index] = { ...posts[index], ...updates };
  await writeAll(posts);
  return posts[index];
}

export async function getDuePosts() {
  const posts = await readAll();
  const now = Date.now();

  return posts.filter(
    (post) =>
      post.status === "scheduled" &&
      post.scheduledAt &&
      new Date(post.scheduledAt).getTime() <= now
  );
}
