import express from "express";
import cors from "cors";
import "dotenv/config";
import publishRoutes from "./routes/publish.js";
import postsRoutes from "./routes/posts.js";
import { startScheduler } from "./services/scheduler.js";

// This file's only job is to create and start the server.
// Route definitions live in ./routes so this file stays short and
// doesn't grow into a dumping ground as the API surface grows.

const app = express();
// Default changed from 5000 → 5050: on macOS, port 5000 is claimed by
// the AirPlay Receiver (Control Center) by default, which causes a
// confusing EADDRINUSE error the first time anyone runs this. 5050
// avoids that out of the box.
const PORT = process.env.PORT || 5050;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ status: "ok", message: "Post Composer API is running." });
});

app.use("/api/publish", publishRoutes);
app.use("/api/posts", postsRoutes);

// More route modules will be mounted here as we build them, e.g.:
// app.use("/api/platforms", platformRoutes);
// app.use("/api/validate", validateRoutes);
// app.use("/api/auth", authRoutes);

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  startScheduler();
});
