import { useContext } from "react";
import { PlatformContext } from "../context/PlatformContext.jsx";

// Wraps useContext so components never import PlatformContext directly.
// The thrown error here is a deliberate guardrail: it turns "selection
// state is silently undefined" into a clear message during development.
export function usePlatformSelection() {
  const context = useContext(PlatformContext);

  if (!context) {
    throw new Error(
      "usePlatformSelection must be used within a <PlatformProvider>"
    );
  }

  return context;
}
