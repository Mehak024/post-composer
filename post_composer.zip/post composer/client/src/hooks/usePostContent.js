import { useContext } from "react";
import { PostContext } from "../context/PostContext.jsx";

export function usePostContent() {
  const context = useContext(PostContext);

  if (!context) {
    throw new Error("usePostContent must be used within a <PostProvider>");
  }

  return context;
}
