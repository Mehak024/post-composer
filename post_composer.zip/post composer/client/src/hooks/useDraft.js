import { useState, useCallback, useEffect } from "react";
import { usePostContent } from "./usePostContent.js";
import { usePlatformSelection } from "./usePlatformSelection.js";
import { useMedia } from "./useMedia.js";
import { useSchedule } from "./useSchedule.js";
import {
  getStorageItem,
  setStorageItem,
  removeStorageItem,
} from "../utils/storage.js";
import { STORAGE_KEYS, MEDIA_DRAFT_SIZE_LIMIT } from "../utils/constants.js";

// Reads a File as a base64 data URL. Only ever called for images under
// MEDIA_DRAFT_SIZE_LIMIT — see shouldPersistMedia below.
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Video is never persisted (data URLs for video get huge fast), and
// large images are skipped too so one draft save can't blow the whole
// localStorage quota for the app.
function shouldPersistMedia(media) {
  return Boolean(
    media && media.mediaType === "image" && media.file && media.size <= MEDIA_DRAFT_SIZE_LIMIT
  );
}

// Bridges Post/Platform/Media/Schedule context + localStorage so a
// "draft" is a single snapshot of everything the user has entered —
// restoring one without the rest would leave the UI half-restored.
export function useDraft() {
  const { title, setTitle, clearTitle, content, setContent, clearContent } =
    usePostContent();
  const { selectedIds, replaceSelection } = usePlatformSelection();
  const { media, setMediaFromDraft, clearMedia } = useMedia();
  const { scheduledAt, setScheduledAt, clearScheduledAt } = useSchedule();

  const [hasSavedDraft, setHasSavedDraft] = useState(false);
  const [feedback, setFeedback] = useState(null); // { type: "success" | "error", message }

  // Check once on mount whether a draft already exists, so "Restore"
  // can start correctly enabled/disabled without waiting for an action.
  useEffect(() => {
    setHasSavedDraft(Boolean(getStorageItem(STORAGE_KEYS.DRAFT)));
  }, []);

  // Feedback messages ("Draft saved") are transient by design.
  useEffect(() => {
    if (!feedback) return undefined;
    const timeout = setTimeout(() => setFeedback(null), 2500);
    return () => clearTimeout(timeout);
  }, [feedback]);

  const saveDraft = useCallback(async () => {
    let mediaSnapshot = null;

    if (shouldPersistMedia(media)) {
      try {
        const dataUrl = await fileToDataUrl(media.file);
        mediaSnapshot = { previewUrl: dataUrl, mediaType: "image", name: media.name };
      } catch {
        mediaSnapshot = null;
      }
    } else if (media) {
      // Video, or an image too large to persist: remember that
      // *something* was attached so restore can prompt for it, without
      // storing the actual bytes.
      mediaSnapshot = {
        previewUrl: null,
        mediaType: media.mediaType,
        name: media.name,
        needsReattach: true,
      };
    }

    const saved = setStorageItem(STORAGE_KEYS.DRAFT, {
      title,
      content,
      selectedIds,
      scheduledAt,
      media: mediaSnapshot,
      savedAt: Date.now(),
    });

    setHasSavedDraft(saved);
    setFeedback(
      saved
        ? { type: "success", message: "Draft saved" }
        : { type: "error", message: "Couldn't save draft" }
    );
  }, [title, content, selectedIds, scheduledAt, media]);

  const restoreDraft = useCallback(() => {
    const draft = getStorageItem(STORAGE_KEYS.DRAFT);

    if (!draft) {
      setFeedback({ type: "error", message: "No saved draft found" });
      return;
    }

    setTitle(draft.title ?? "");
    setContent(draft.content ?? "");
    replaceSelection(draft.selectedIds ?? []);
    setScheduledAt(draft.scheduledAt ?? "");

    if (draft.media?.previewUrl) {
      setMediaFromDraft(draft.media);
      setFeedback({ type: "success", message: "Draft restored" });
    } else if (draft.media?.needsReattach) {
      clearMedia();
      setFeedback({
        type: "error",
        message: `Draft restored — please re-attach "${draft.media.name}"`,
      });
    } else {
      clearMedia();
      setFeedback({ type: "success", message: "Draft restored" });
    }
  }, [setTitle, setContent, replaceSelection, setScheduledAt, setMediaFromDraft, clearMedia]);

  // Clears both the current editor state AND the saved draft, so
  // "Clear draft" leaves nothing behind in either place.
  const clearDraft = useCallback(() => {
    const removed = removeStorageItem(STORAGE_KEYS.DRAFT);
    setHasSavedDraft(false);
    clearTitle();
    clearContent();
    replaceSelection([]);
    clearScheduledAt();
    clearMedia();
    setFeedback(
      removed
        ? { type: "success", message: "Draft cleared" }
        : { type: "error", message: "Couldn't clear draft" }
    );
  }, [clearTitle, clearContent, replaceSelection, clearScheduledAt, clearMedia]);

  return { hasSavedDraft, feedback, saveDraft, restoreDraft, clearDraft };
}
