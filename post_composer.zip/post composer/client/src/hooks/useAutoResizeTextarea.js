import { useEffect, useRef } from "react";

// Resets height to "auto" first so shrinking (e.g. after deleting text)
// works too, not just growing — otherwise scrollHeight would be stuck
// at its previous maximum.
export function useAutoResizeTextarea(value) {
  const textareaRef = useRef(null);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;

    el.style.height = "auto";
    el.style.height = `${el.scrollHeight}px`;
  }, [value]);

  return textareaRef;
}
