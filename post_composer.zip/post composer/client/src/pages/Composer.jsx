import { usePlatformSelection } from "../hooks/usePlatformSelection.js";
import PlatformSelector from "../components/PlatformSelector.jsx";
import TitleInput from "../components/TitleInput.jsx";
import ComposerTextarea from "../components/ComposerTextarea.jsx";
import TextStats from "../components/TextStats.jsx";
import MediaUpload from "../components/MediaUpload.jsx";
import ScheduleField from "../components/ScheduleField.jsx";
import PlatformCountersList from "../components/PlatformCountersList.jsx";
import PreviewList from "../components/previews/PreviewList.jsx";
import PublishButton from "../components/PublishButton.jsx";
import PostsFeed from "../components/PostsFeed.jsx";
import DraftControls from "../components/DraftControls.jsx";

// The main (and for now, only) page of the app: Select platforms →
// Title → Write → Media → Schedule → Track limits → Preview → Publish.
function Composer() {
  const { selectedPlatforms } = usePlatformSelection();

  return (
    <div className="min-h-screen px-6 py-10 md:py-16">
      <div className="max-w-5xl mx-auto">
        <header className="mb-8">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Post Composer
          </p>
          <h1 className="text-3xl font-display font-semibold text-ink dark:text-ink-dark">
            Create a post
          </h1>
          <p className="text-ink-muted mt-1">
            Write once, tailor it to every platform, and schedule it to go out
            later.
          </p>
        </header>

        {/* Utility toolbar, not a numbered step — draft actions are
            available at any point in the flow, not tied to one step. */}
        <section className="mb-10 pb-8 border-b border-border">
          <DraftControls />
        </section>

        <section>
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Step 1
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-1">
            Where do you want to post?
          </h2>
          <p className="text-ink-muted mb-4">
            Select one or more platforms. Each has its own character limit
            and preview style.
          </p>

          <PlatformSelector />

          <p
            className="mt-6 text-sm font-mono text-ink-subtle"
            aria-live="polite"
          >
            {selectedPlatforms.length === 0
              ? "No platforms selected yet"
              : `${selectedPlatforms.length} platform${
                  selectedPlatforms.length > 1 ? "s" : ""
                } selected`}
          </p>
        </section>

        <section className="mt-10">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Step 2
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-1">
            Give it a title
          </h2>
          <p className="text-ink-muted mb-4">
            A short headline for this post. Required.
          </p>

          <TitleInput />
        </section>

        <section className="mt-10">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Step 3
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-1">
            Write your post
          </h2>
          <p className="text-ink-muted mb-4">
            One draft, tailored automatically to every platform you picked
            above.
          </p>

          <ComposerTextarea />
          <TextStats />
        </section>

        <section className="mt-10">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Step 4
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-1">
            Add media
          </h2>
          <p className="text-ink-muted mb-4">
            Optionally attach an image or video. You can preview or remove it
            any time before publishing.
          </p>

          <MediaUpload />
        </section>

        <section className="mt-10">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Step 5
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-1">
            Schedule it (optional)
          </h2>
          <p className="text-ink-muted mb-4">
            Pick a future date and time to schedule this post, or leave it
            blank to publish right away.
          </p>

          <ScheduleField />
        </section>

        <section className="mt-10">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Step 6
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-1">
            Track your limits
          </h2>
          <p className="text-ink-muted mb-4">
            Each platform has its own limit — watch the ring fill as you
            type.
          </p>

          <PlatformCountersList />
        </section>

        <section className="mt-10">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Step 7
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-1">
            Preview
          </h2>
          <p className="text-ink-muted mb-4">
            A rough look at how this post will appear on each platform.
          </p>

          <PreviewList />
        </section>

        <section className="mt-10">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Step 8
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-4">
            Publish
          </h2>

          <PublishButton />
        </section>

        {/* Utility section, not a numbered step — this is a live view
            into the backend, not part of the compose flow itself. */}
        <section className="mt-10 pt-8 border-t border-border">
          <p className="text-sm font-mono text-compose uppercase tracking-wide mb-2">
            Your posts
          </p>
          <h2 className="text-2xl font-display font-semibold text-ink dark:text-ink-dark mb-1">
            Scheduled &amp; published
          </h2>
          <p className="text-ink-muted mb-4">
            Updates automatically — a scheduled post flips to "Published"
            here on its own once its time arrives, even without touching
            anything.
          </p>

          <PostsFeed />
        </section>
      </div>
    </div>
  );
}

export default Composer;
