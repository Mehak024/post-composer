// -----------------------------------------------------------------------
// Declarative description of how each platform's preview should look.
// PostPreviewCard reads this instead of branching on platform.id itself,
// so adding a 7th platform later means adding one entry here, not a new
// component.
//
// layout:
//   "text-actions" — Facebook/LinkedIn style: icon + text label per action
//   "icon-count"   — Twitter/Threads/YouTube style: icon-only, tightly packed
//   "media"        — Instagram style: adds an image placeholder block
// -----------------------------------------------------------------------

export const PREVIEW_CONFIG = {
  facebook: {
    handle: "Your Page",
    layout: "text-actions",
    hasMedia: false,
    actions: [
      { key: "thumbsup", label: "Like" },
      { key: "comment", label: "Comment" },
      { key: "share", label: "Share" },
    ],
  },
  instagram: {
    handle: "@yourhandle",
    layout: "media",
    hasMedia: true,
    actions: [{ key: "heart" }, { key: "comment" }, { key: "share" }, { key: "save" }],
  },
  twitter: {
    handle: "@yourhandle",
    layout: "icon-count",
    hasMedia: false,
    actions: [
      { key: "comment" },
      { key: "retweet" },
      { key: "heart" },
      { key: "share" },
    ],
  },
  pinterest: {
    handle: "Your Pinterest Profile",
    layout: "media",
    hasMedia: true,
    actions: [{ key: "heart" }, { key: "save", label: "Save" }, { key: "share" }],
  },
  threads: {
    handle: "@yourhandle",
    layout: "icon-count",
    hasMedia: false,
    actions: [
      { key: "heart" },
      { key: "comment" },
      { key: "retweet" },
      { key: "share" },
    ],
  },
  quora: {
    handle: "Your Quora Profile",
    layout: "text-actions",
    hasMedia: false,
    actions: [
      { key: "thumbsup", label: "Upvote" },
      { key: "comment", label: "Comment" },
      { key: "share", label: "Share" },
    ],
  },
};
