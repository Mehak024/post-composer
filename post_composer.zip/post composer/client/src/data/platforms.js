// -----------------------------------------------------------------------
// Single source of truth for every supported platform.
// Every other module (selector, counters, validation, preview) reads
// from this file instead of hardcoding names/limits, so adding a new
// platform later means editing exactly one place.
// -----------------------------------------------------------------------

export const PLATFORM_IDS = {
  TWITTER: "twitter",
  THREADS: "threads",
  PINTEREST: "pinterest",
  INSTAGRAM: "instagram",
  QUORA: "quora",
  FACEBOOK: "facebook",
};

export const PLATFORMS = [
  {
    id: PLATFORM_IDS.TWITTER,
    name: "Twitter / X",
    description: "Short, punchy updates",
    charLimit: 280,
    color: "#111111",
    iconKey: "twitter",
  },
  {
    id: PLATFORM_IDS.THREADS,
    name: "Threads",
    description: "Conversational, text-based posts",
    charLimit: 500,
    color: "#4A4A4A",
    iconKey: "threads",
  },
  {
    id: PLATFORM_IDS.PINTEREST,
    name: "Pinterest",
    description: "Visual pins with a short description",
    charLimit: 500,
    color: "#E60023",
    iconKey: "pinterest",
  },
  {
    id: PLATFORM_IDS.INSTAGRAM,
    name: "Instagram",
    description: "Visual-first captions for feed posts",
    charLimit: 2200,
    color: "#E1306C",
    iconKey: "instagram",
  },
  {
    id: PLATFORM_IDS.QUORA,
    name: "Quora",
    description: "Long-form answers and posts",
    charLimit: 3000,
    color: "#B92B27",
    iconKey: "quora",
  },
  {
    id: PLATFORM_IDS.FACEBOOK,
    name: "Facebook",
    description: "Long-form posts for friends, groups, and pages",
    charLimit: 63206,
    color: "#1877F2",
    iconKey: "facebook",
  },
];

// Quick lookup helper — used by counters/validation/preview so they don't
// each re-implement `PLATFORMS.find(...)`.
export const getPlatformById = (id) =>
  PLATFORMS.find((platform) => platform.id === id);
