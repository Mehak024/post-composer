import { usePostContent } from "../hooks/usePostContent.js";
import { useAutoResizeTextarea } from "../hooks/useAutoResizeTextarea.js";

// The single source of truth for what the user is writing.
// Deliberately dumb: no counting or validation logic here, it just
// reads/writes PostContext and handles its own resizing.
function ComposerTextarea() {
  const { content, setContent } = usePostContent();
  const textareaRef = useAutoResizeTextarea(content);

  return (
    <textarea
      ref={textareaRef}
      value={content}
      onChange={(event) => setContent(event.target.value)}
      placeholder="What do you want to share?"
      rows={4}
      aria-label="Post content"
      className="w-full resize-none overflow-hidden rounded-2xl border border-border
        bg-surface dark:bg-surface-dark text-ink dark:text-ink-dark
        placeholder:text-ink-subtle px-5 py-4 text-base leading-relaxed shadow-soft
        focus:outline-none focus-visible:ring-2 focus-visible:ring-compose/40
        focus:border-compose transition-colors duration-150"
    />
  );
}

export default ComposerTextarea;
