// -----------------------------------------------------------------------
// A small circular meter that fills as the post approaches a platform's
// character limit — the "ink ring." Uses Tailwind's `stroke-current` +
// a text-color utility so the ring's color stays driven by the same
// status tokens (status.success/warning/danger) as the rest of the app,
// rather than hardcoding hex values here.
// -----------------------------------------------------------------------

const STATUS_CLASS = {
  success: "text-status-success",
  warning: "text-status-warning",
  danger: "text-status-danger",
};

function CharacterRing({ percentage, status, size = 40, strokeWidth = 4 }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedPercentage = Math.min(Math.max(percentage, 0), 100);
  const offset = circumference * (1 - clampedPercentage / 100);

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className="shrink-0"
      aria-hidden="true"
    >
      {/* Track */}
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        strokeWidth={strokeWidth}
        className="stroke-border"
        fill="none"
      />
      {/* Fill */}
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        strokeWidth={strokeWidth}
        fill="none"
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        className={`stroke-current transition-all duration-200 ease-out ${STATUS_CLASS[status]}`}
      />
    </svg>
  );
}

export default CharacterRing;
