import { useMemo } from "react";
import { useSchedule } from "../hooks/useSchedule.js";
import { isScheduleValid } from "../utils/validation.js";

// Formats "now" as a `datetime-local` min value (YYYY-MM-DDTHH:mm) in the
// user's local time, so the native date picker itself refuses to open on
// a past date — belt-and-suspenders alongside the JS validation below.
function nowAsDatetimeLocal() {
  const now = new Date();
  now.setSeconds(0, 0);
  const offset = now.getTimezoneOffset();
  const local = new Date(now.getTime() - offset * 60000);
  return local.toISOString().slice(0, 16);
}

// Optional — leaving it blank means "publish immediately." If the user
// does pick a date/time, it still can't be in the past.
function ScheduleField() {
  const { scheduledAt, setScheduledAt, clearScheduledAt } = useSchedule();
  const min = useMemo(() => nowAsDatetimeLocal(), []);

  const touched = scheduledAt.length > 0;
  const valid = isScheduleValid(scheduledAt);

  return (
    <div>
      <label
        htmlFor="post-schedule"
        className="block text-sm font-medium text-ink dark:text-ink-dark mb-2"
      >
        Schedule date &amp; time{" "}
        <span className="text-ink-subtle font-normal">(optional)</span>
      </label>

      <div className="flex flex-wrap items-center gap-3">
        <input
          id="post-schedule"
          type="datetime-local"
          value={scheduledAt}
          min={min}
          onChange={(event) => setScheduledAt(event.target.value)}
          aria-invalid={touched && !valid}
          className={`w-full sm:w-auto rounded-2xl border bg-surface dark:bg-surface-dark
            text-ink dark:text-ink-dark px-5 py-3.5 text-base shadow-soft
            focus:outline-none focus-visible:ring-2 focus-visible:ring-compose/40
            transition-colors duration-150
            ${
              touched && !valid
                ? "border-status-danger focus:border-status-danger"
                : "border-border focus:border-compose"
            }`}
        />

        {touched && (
          <button
            type="button"
            onClick={clearScheduledAt}
            className="text-xs font-medium text-ink-muted hover:text-status-danger hover:underline"
          >
            Clear — publish immediately instead
          </button>
        )}
      </div>

      <p className="mt-2 text-xs font-mono text-ink-subtle">
        {!touched && "Leave blank to publish immediately, or pick a future date/time to schedule it"}
        {touched && !valid && (
          <span className="text-status-danger">
            Please choose a date and time in the future
          </span>
        )}
        {touched && valid && "Looks good"}
      </p>
    </div>
  );
}

export default ScheduleField;
