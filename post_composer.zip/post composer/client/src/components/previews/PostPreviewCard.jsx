import PlatformIcon from "../icons/PlatformIcon.jsx";
import ActionIcon from "../icons/ActionIcon.jsx";
import { PREVIEW_CONFIG } from "../../data/previewConfig.js";

// One component, config-driven layout — rather than a near-duplicate
// component per platform. Visual distinctiveness comes from the
// PREVIEW_CONFIG entry (media block, action style, handle format) and
// the platform's own brand color, not from separate JSX per platform.
function PostPreviewCard({ platform, content, media = null }) {
  const { name, color, iconKey } = platform;
  const config = PREVIEW_CONFIG[platform.id];
  const hasContent = content.trim().length > 0;

  return (
    <div className="rounded-2xl border border-border bg-surface dark:bg-surface-dark shadow-soft overflow-hidden">
      {/* Header: avatar, handle, platform label */}
      <div className="flex items-center gap-2.5 px-4 pt-4">
        <span
          className="flex items-center justify-center w-8 h-8 rounded-full shrink-0 text-white"
          style={{ backgroundColor: color }}
        >
          <PlatformIcon iconKey={iconKey} className="w-3.5 h-3.5" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-medium text-ink dark:text-ink-dark truncate">
            {config.handle}
          </p>
          <p className="text-xs text-ink-subtle">Just now · {name}</p>
        </div>
      </div>

      {/* Body text */}
      <div className="px-4 pt-3">
        <p
          className={`text-sm whitespace-pre-wrap break-words leading-relaxed ${
            hasContent
              ? "text-ink dark:text-ink-dark"
              : "text-ink-subtle italic"
          }`}
        >
          {hasContent ? content : "Nothing written yet — start typing above."}
        </p>
      </div>

      {/* Media block (Instagram/Pinterest-style layout): shows the real
          upload if one exists, otherwise a placeholder. */}
      {config.hasMedia && (
        <div className="mx-4 mt-3 aspect-square rounded-xl bg-canvas dark:bg-canvas-dark border border-border overflow-hidden flex items-center justify-center">
          {media ? (
            media.mediaType === "video" ? (
              <video src={media.previewUrl} className="w-full h-full object-cover" muted />
            ) : (
              <img
                src={media.previewUrl}
                alt="Post media preview"
                className="w-full h-full object-cover"
              />
            )
          ) : (
            <span className="text-xs text-ink-subtle border border-dashed border-border rounded-lg px-3 py-1">
              No media attached
            </span>
          )}
        </div>
      )}

      {/* Footer actions, style driven by config.layout */}
      <div
        className={`flex items-center gap-5 px-4 py-3 mt-3 border-t border-border ${
          config.layout === "text-actions" ? "justify-between gap-2" : ""
        }`}
      >
        {config.actions.map((action) => (
          <span
            key={action.key}
            className={`flex items-center gap-1.5 text-ink-muted text-xs ${
              config.layout === "text-actions" ? "flex-1 justify-center" : ""
            }`}
          >
            <ActionIcon actionKey={action.key} className="w-4 h-4" />
            {action.label && <span>{action.label}</span>}
          </span>
        ))}
      </div>
    </div>
  );
}

export default PostPreviewCard;
