import { usePlatformSelection } from "../../hooks/usePlatformSelection.js";
import { usePostContent } from "../../hooks/usePostContent.js";
import { useMedia } from "../../hooks/useMedia.js";
import PostPreviewCard from "./PostPreviewCard.jsx";

function PreviewList() {
  const { selectedPlatforms } = usePlatformSelection();
  const { content } = usePostContent();
  const { media } = useMedia();

  if (selectedPlatforms.length === 0) {
    return (
      <p className="text-sm text-ink-subtle italic">
        Select a platform above to see how your post will look.
      </p>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {selectedPlatforms.map((platform) => (
        <PostPreviewCard
          key={platform.id}
          platform={platform}
          content={content}
          media={media}
        />
      ))}
    </div>
  );
}

export default PreviewList;
