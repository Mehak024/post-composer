import { usePlatformSelection } from "../hooks/usePlatformSelection.js";
import { usePostContent } from "../hooks/usePostContent.js";
import CharacterCounter from "./CharacterCounter.jsx";

// Bridges the two contexts: pulls which platforms are selected from
// PlatformContext and the shared draft's length from PostContext, then
// renders one counter per selected platform.
function PlatformCountersList() {
  const { selectedPlatforms } = usePlatformSelection();
  const { characterCount } = usePostContent();

  if (selectedPlatforms.length === 0) {
    return (
      <p className="text-sm text-ink-subtle italic">
        Select a platform above to see its character limit here.
      </p>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {selectedPlatforms.map((platform) => (
        <CharacterCounter
          key={platform.id}
          platform={platform}
          characterCount={characterCount}
        />
      ))}
    </div>
  );
}

export default PlatformCountersList;
