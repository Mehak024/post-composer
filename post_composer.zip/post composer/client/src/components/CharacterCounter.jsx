import PlatformIcon from "./icons/PlatformIcon.jsx";
import CharacterRing from "./CharacterRing.jsx";
import {
  getCharacterStatus,
  getRemainingCharacters,
  getUsagePercentage,
} from "../utils/characterStatus.js";

const STATUS_TEXT_CLASS = {
  success: "text-status-success",
  warning: "text-status-warning",
  danger: "text-status-danger",
};

const STATUS_MESSAGE = {
  success: "Ready to publish",
  warning: "Close to limit",
  danger: "Limit exceeded",
};

const STATUS_ICON = {
  success: "✓",
  warning: "⚠",
  danger: "✖",
};

// One row per platform: the same draft's character count, measured
// against *this* platform's limit. Purely presentational — all the
// threshold math lives in utils/characterStatus.js.
function CharacterCounter({ platform, characterCount }) {
  const { name, charLimit, color, iconKey } = platform;

  const status = getCharacterStatus(characterCount, charLimit);
  const remaining = getRemainingCharacters(characterCount, charLimit);
  const percentage = getUsagePercentage(characterCount, charLimit);

  return (
    <div className="flex items-center gap-3 rounded-xl border border-border bg-surface dark:bg-surface-dark px-4 py-3 shadow-soft">
      <span
        className="flex items-center justify-center w-8 h-8 rounded-lg shrink-0"
        style={{ backgroundColor: `${color}1A`, color }}
      >
        <PlatformIcon iconKey={iconKey} className="w-4 h-4" />
      </span>

      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-ink dark:text-ink-dark truncate">
          {name}
        </p>
        <p className={`text-xs font-mono ${STATUS_TEXT_CLASS[status]}`}>
          {characterCount.toLocaleString()} / {charLimit.toLocaleString()}
          {remaining < 0
            ? ` · ${Math.abs(remaining).toLocaleString()} over`
            : ` · ${remaining.toLocaleString()} left`}
        </p>
        <p
          className={`text-xs font-medium mt-0.5 ${STATUS_TEXT_CLASS[status]}`}
        >
          <span aria-hidden="true">{STATUS_ICON[status]}</span>{" "}
          {STATUS_MESSAGE[status]}
        </p>
      </div>

      <CharacterRing percentage={percentage} status={status} />
    </div>
  );
}

export default CharacterCounter;
