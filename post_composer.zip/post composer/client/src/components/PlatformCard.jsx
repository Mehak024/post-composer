import PlatformIcon from "./icons/PlatformIcon.jsx";

// A single platform's selectable card.
// Purely presentational + one click handler — it doesn't know *how*
// selection is stored, only that it receives `selected` and calls
// `onToggle` when clicked. That keeps it reusable and easy to test.
function PlatformCard({ platform, selected, invalid = false, onToggle }) {
  const { name, description, charLimit, color, iconKey } = platform;

  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={selected}
      aria-invalid={invalid}
      aria-label={
        invalid
          ? `${name}, character limit exceeded`
          : `${name}, ${charLimit.toLocaleString()} character limit`
      }
      onClick={() => onToggle(platform.id)}
      className={`relative text-left w-full rounded-2xl border p-4 bg-surface dark:bg-surface-dark
        transition-all duration-200 ease-out
        hover:shadow-card hover:-translate-y-0.5
        focus-visible:outline focus-visible:outline-2 focus-visible:outline-compose
        ${
          invalid
            ? "border-status-danger ring-2 ring-status-danger/30 shadow-card"
            : selected
            ? "border-compose ring-2 ring-compose/30 shadow-card"
            : "border-border shadow-soft"
        }`}
    >
      {/* Selection / status badge */}
      {selected && (
        <span
          className={`absolute -top-2 -right-2 w-6 h-6 rounded-full text-white
            flex items-center justify-center text-xs shadow-soft animate-fade-in
            ${invalid ? "bg-status-danger" : "bg-compose"}`}
          aria-hidden="true"
        >
          {invalid ? "!" : "✓"}
        </span>
      )}

      <div className="flex items-start gap-3">
        <span
          className="flex items-center justify-center w-10 h-10 rounded-xl shrink-0"
          style={{ backgroundColor: `${color}1A`, color }}
        >
          <PlatformIcon iconKey={iconKey} className="w-5 h-5" />
        </span>

        <div className="min-w-0">
          <h3 className="font-display font-semibold text-ink dark:text-ink-dark truncate">
            {name}
          </h3>
          <p className="text-sm text-ink-muted mt-0.5 leading-snug">
            {description}
          </p>
          <p className="text-xs font-mono text-ink-subtle mt-2">
            {charLimit.toLocaleString()} char limit
          </p>
        </div>
      </div>
    </button>
  );
}

export default PlatformCard;
