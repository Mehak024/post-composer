import { useRef } from "react";
import { useMedia } from "../hooks/useMedia.js";

// Optional image/video attachment. Purely a file picker + preview +
// remove — the actual object URL lifecycle (create/revoke) lives in
// MediaContext so it survives even if this component unmounts mid-flow.
function MediaUpload() {
  const { media, setMedia, clearMedia } = useMedia();
  const inputRef = useRef(null);

  const handleFileChange = (event) => {
    const file = event.target.files?.[0];
    if (file) setMedia(file);
    // Reset the input so choosing the same file again still fires onChange.
    event.target.value = "";
  };

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*,video/*"
        onChange={handleFileChange}
        className="hidden"
        aria-label="Upload image or video"
      />

      {!media ? (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="w-full rounded-2xl border border-dashed border-border bg-surface dark:bg-surface-dark
            text-ink-muted text-sm px-5 py-8 text-center shadow-soft
            hover:border-compose hover:text-compose transition-colors duration-150"
        >
          Click to upload an image or video
          <span className="block text-xs text-ink-subtle mt-1">
            Optional — PNG, JPG, MP4, and more
          </span>
        </button>
      ) : (
        <div className="rounded-2xl border border-border bg-surface dark:bg-surface-dark p-4 shadow-soft">
          <div className="flex items-start gap-4">
            <div className="w-24 h-24 rounded-xl overflow-hidden shrink-0 bg-canvas dark:bg-canvas-dark border border-border">
              {media.mediaType === "video" ? (
                <video
                  src={media.previewUrl}
                  className="w-full h-full object-cover"
                  muted
                />
              ) : (
                <img
                  src={media.previewUrl}
                  alt="Upload preview"
                  className="w-full h-full object-cover"
                />
              )}
            </div>

            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-ink dark:text-ink-dark truncate">
                {media.name}
              </p>
              <p className="text-xs text-ink-subtle mt-0.5 capitalize">
                {media.mediaType}
                {media.restored && " · restored from draft"}
              </p>

              <button
                type="button"
                onClick={clearMedia}
                className="mt-3 text-xs font-medium text-status-danger hover:underline"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MediaUpload;
