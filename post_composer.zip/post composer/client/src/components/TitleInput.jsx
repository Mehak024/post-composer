import { usePostContent } from "../hooks/usePostContent.js";
import { TITLE_MAX_LENGTH } from "../utils/constants.js";

// Mandatory single-line headline for the post. Deliberately its own
// small component (mirroring ComposerTextarea) rather than folded into
// the textarea section, since Title and Description are validated and
// laid out as separate required fields.
function TitleInput() {
  const { title, setTitle, titleCharacterCount } = usePostContent();

  const remaining = TITLE_MAX_LENGTH - titleCharacterCount;
  const overLimit = remaining < 0;
  const isEmpty = title.trim().length === 0;

  return (
    <div>
      <label
        htmlFor="post-title"
        className="block text-sm font-medium text-ink dark:text-ink-dark mb-2"
      >
        Title <span className="text-status-danger">*</span>
      </label>

      <input
        id="post-title"
        type="text"
        value={title}
        onChange={(event) => setTitle(event.target.value.slice(0, TITLE_MAX_LENGTH + 20))}
        placeholder="Give your post a title"
        aria-required="true"
        aria-invalid={overLimit}
        className={`w-full rounded-2xl border bg-surface dark:bg-surface-dark
          text-ink dark:text-ink-dark placeholder:text-ink-subtle px-5 py-3.5
          text-base shadow-soft focus:outline-none focus-visible:ring-2
          focus-visible:ring-compose/40 transition-colors duration-150
          ${
            overLimit
              ? "border-status-danger focus:border-status-danger"
              : "border-border focus:border-compose"
          }`}
      />

      <div className="flex items-center justify-between mt-2 text-xs font-mono">
        <span className={isEmpty ? "text-ink-subtle" : "text-ink-subtle"}>
          {isEmpty && "Title is required"}
        </span>
        <span className={overLimit ? "text-status-danger" : "text-ink-subtle"}>
          {titleCharacterCount}/{TITLE_MAX_LENGTH}
        </span>
      </div>
    </div>
  );
}

export default TitleInput;
