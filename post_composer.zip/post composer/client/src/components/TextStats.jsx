import { usePostContent } from "../hooks/usePostContent.js";

// Shows the overall word/character count for the raw text — not tied to
// any single platform's limit yet. Module 4 adds a per-platform version
// of this that reacts to each platform's charLimit.
function TextStats() {
  const { characterCount, wordCount } = usePostContent();

  return (
    <div
      className="flex items-center gap-3 mt-2 text-xs font-mono text-ink-subtle"
      aria-live="polite"
    >
      <span>
        {wordCount} {wordCount === 1 ? "word" : "words"}
      </span>
      <span aria-hidden="true">·</span>
      <span>
        {characterCount.toLocaleString()}{" "}
        {characterCount === 1 ? "character" : "characters"}
      </span>
    </div>
  );
}

export default TextStats;
