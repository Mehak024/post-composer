import { PLATFORMS } from "../data/platforms.js";
import { usePlatformSelection } from "../hooks/usePlatformSelection.js";
import { usePostContent } from "../hooks/usePostContent.js";
import { validatePlatform } from "../utils/validation.js";
import PlatformCard from "./PlatformCard.jsx";

// Renders every platform as a selectable card in a responsive grid.
// Also cross-references each platform against the shared draft's length
// so a selected-but-over-limit platform can be highlighted in place,
// without the card needing to know how validation works itself.
function PlatformSelector() {
  const { isSelected, togglePlatform } = usePlatformSelection();
  const { characterCount } = usePostContent();

  return (
    <div
      role="group"
      aria-label="Select platforms to post to"
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
    >
      {PLATFORMS.map((platform) => {
        const selected = isSelected(platform.id);
        const invalid =
          selected && !validatePlatform(platform, characterCount).isValid;

        return (
          <PlatformCard
            key={platform.id}
            platform={platform}
            selected={selected}
            invalid={invalid}
            onToggle={togglePlatform}
          />
        );
      })}
    </div>
  );
}

export default PlatformSelector;
