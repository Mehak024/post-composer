import { useDraft } from "../hooks/useDraft.js";

const FEEDBACK_CLASS = {
  success: "text-status-success",
  error: "text-status-danger",
};

// A utility toolbar rather than a numbered step — draft actions aren't
// part of the sequential compose flow, they're available at any point
// in it.
function DraftControls() {
  const { hasSavedDraft, feedback, saveDraft, restoreDraft, clearDraft } =
    useDraft();

  return (
    <div className="flex flex-wrap items-center gap-3">
      <button
        type="button"
        onClick={saveDraft}
        className="px-4 py-2 rounded-xl text-sm font-medium border border-border
          bg-surface dark:bg-surface-dark text-ink dark:text-ink-dark
          hover:border-compose transition-colors duration-150"
      >
        Save draft
      </button>

      <button
        type="button"
        onClick={restoreDraft}
        disabled={!hasSavedDraft}
        className={`px-4 py-2 rounded-xl text-sm font-medium border transition-colors duration-150 ${
          hasSavedDraft
            ? "border-border bg-surface dark:bg-surface-dark text-ink dark:text-ink-dark hover:border-compose"
            : "border-border bg-canvas dark:bg-canvas-dark text-ink-subtle cursor-not-allowed"
        }`}
      >
        Restore draft
      </button>

      <button
        type="button"
        onClick={clearDraft}
        className="px-4 py-2 rounded-xl text-sm font-medium border border-border
          bg-surface dark:bg-surface-dark text-status-danger
          hover:border-status-danger transition-colors duration-150"
      >
        Clear draft
      </button>

      {feedback && (
        <span
          role="status"
          className={`text-xs font-mono animate-fade-in ${FEEDBACK_CLASS[feedback.type]}`}
        >
          {feedback.message}
        </span>
      )}
    </div>
  );
}

export default DraftControls;
