import { usePosts } from "../hooks/usePosts.js";
import { getPlatformById } from "../data/platforms.js";
import PlatformIcon from "./icons/PlatformIcon.jsx";

const STATUS_BADGE = {
  scheduled: "bg-status-warningSoft text-status-warning",
  published: "bg-status-successSoft text-status-success",
};

const STATUS_LABEL = {
  scheduled: "Scheduled",
  published: "Published",
};

function formatTime(iso) {
  if (!iso) return null;
  return new Date(iso).toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

// Proof that scheduling is real, not just a UI state: this list is
// backed by GET /api/posts, which PostsContext polls every few seconds.
// A post you schedule for "1 minute from now" will visibly flip from
// "Scheduled" to "Published" here on its own — the backend scheduler
// (services/scheduler.js) does that independently of this tab being open.
function PostsFeed() {
  const { posts, isLoading, error } = usePosts();

  if (isLoading) {
    return <p className="text-sm text-ink-subtle italic">Loading posts…</p>;
  }

  if (error) {
    return <p className="text-sm text-status-danger">{error}</p>;
  }

  if (posts.length === 0) {
    return (
      <p className="text-sm text-ink-subtle italic">
        Nothing published or scheduled yet — publish a post above to see it
        here.
      </p>
    );
  }

  return (
    <div className="space-y-3">
      {posts.map((post) => (
        <div
          key={post.id}
          className="rounded-2xl border border-border bg-surface dark:bg-surface-dark p-4 shadow-soft"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="font-medium text-ink dark:text-ink-dark truncate">
                {post.title}
              </p>
              <p className="text-sm text-ink-muted mt-0.5 line-clamp-2">
                {post.content}
              </p>
            </div>

            <span
              className={`shrink-0 text-xs font-medium px-2.5 py-1 rounded-full ${STATUS_BADGE[post.status]}`}
            >
              {STATUS_LABEL[post.status]}
            </span>
          </div>

          <div className="flex items-center gap-2 mt-3">
            {post.platformIds.map((id) => {
              const platform = getPlatformById(id);
              if (!platform) return null;
              return (
                <span
                  key={id}
                  className="flex items-center justify-center w-6 h-6 rounded-lg"
                  style={{ backgroundColor: `${platform.color}1A`, color: platform.color }}
                  title={platform.name}
                >
                  <PlatformIcon iconKey={platform.iconKey} className="w-3.5 h-3.5" />
                </span>
              );
            })}
          </div>

          <p className="text-xs font-mono text-ink-subtle mt-3">
            {post.status === "scheduled"
              ? `Scheduled for ${formatTime(post.scheduledAt)}`
              : `Published ${formatTime(post.publishedAt)}`}
          </p>
        </div>
      ))}
    </div>
  );
}

export default PostsFeed;
