import { useState } from "react";
import { usePlatformSelection } from "../hooks/usePlatformSelection.js";
import { usePostContent } from "../hooks/usePostContent.js";
import { useSchedule } from "../hooks/useSchedule.js";
import { useMedia } from "../hooks/useMedia.js";
import { usePosts } from "../hooks/usePosts.js";
import { canPublish } from "../utils/validation.js";

// Enforces the *gate* (disabled unless Title, Description, Schedule, and
// every selected platform's character limit are all valid) and, once
// clicked, actually sends the post to the simulated Express backend.
function PublishButton() {
  const { selectedPlatforms, selectedIds } = usePlatformSelection();
  const { title, content, characterCount } = usePostContent();
  const { scheduledAt } = useSchedule();
  const { media } = useMedia();
  const { refresh } = usePosts();

  const [status, setStatus] = useState("idle"); // idle | loading | success | error
  const [resultMessage, setResultMessage] = useState("");

  const publishable = canPublish({
    title,
    content,
    scheduledAt,
    selectedPlatforms,
    characterCount,
  });

  const handlePublish = async () => {
    setStatus("loading");
    setResultMessage("");

    try {
      const response = await fetch("/api/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          content,
          platformIds: selectedIds,
          scheduledAt,
          media: media ? { name: media.name, mediaType: media.mediaType } : null,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        setStatus("error");
        setResultMessage(data.message || "Something went wrong. Please try again.");
        return;
      }

      setStatus("success");
      setResultMessage(data.message || "Post published successfully.");
      refresh();
    } catch {
      setStatus("error");
      setResultMessage("Couldn't reach the server. Is the backend running?");
    }
  };

  const isLoading = status === "loading";

  return (
    <div>
      <button
        type="button"
        onClick={handlePublish}
        disabled={!publishable || isLoading}
        aria-disabled={!publishable || isLoading}
        className={`px-6 py-3 rounded-xl font-medium transition-colors duration-150 w-full sm:w-auto
          ${
            publishable && !isLoading
              ? "bg-compose text-white hover:bg-compose-hover cursor-pointer"
              : "bg-border text-ink-subtle cursor-not-allowed"
          }`}
      >
        {isLoading ? "Publishing…" : "Publish"}
      </button>

      {!publishable && !isLoading && (
        <p className="text-xs text-status-danger mt-2">
          Fill in the Title and Description, select a platform, and fix any
          character limit issues above before publishing.
        </p>
      )}

      {status === "success" && (
        <p className="text-xs text-status-success mt-2" role="status">
          ✓ {resultMessage}
        </p>
      )}

      {status === "error" && (
        <p className="text-xs text-status-danger mt-2" role="status">
          ✖ {resultMessage}
        </p>
      )}
    </div>
  );
}

export default PublishButton;
