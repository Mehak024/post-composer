import { FaFacebook, FaInstagram, FaPinterest, FaQuora } from "react-icons/fa";
import { FaXTwitter, FaThreads } from "react-icons/fa6";

// Maps a platform's `iconKey` (from data/platforms.js) to its icon component.
// Centralizing this mapping means PlatformCard doesn't need a switch
// statement, and swapping icon libraries later only touches this file.
const ICON_MAP = {
  facebook: FaFacebook,
  instagram: FaInstagram,
  twitter: FaXTwitter,
  threads: FaThreads,
  pinterest: FaPinterest,
  quora: FaQuora,
};

function PlatformIcon({ iconKey, className = "" }) {
  const Icon = ICON_MAP[iconKey];

  if (!Icon) return null;

  return <Icon className={className} aria-hidden="true" />;
}

export default PlatformIcon;
