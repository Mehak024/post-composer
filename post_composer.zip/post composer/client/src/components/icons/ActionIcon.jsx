import {
  FaRegHeart,
  FaRegComment,
  FaRetweet,
  FaRegPaperPlane,
  FaRegBookmark,
  FaRegThumbsUp,
  FaRegThumbsDown,
} from "react-icons/fa";

// Same pattern as icons/PlatformIcon.jsx: a lookup table keeps
// PostPreviewCard free of a growing switch statement.
const ACTION_ICON_MAP = {
  heart: FaRegHeart,
  comment: FaRegComment,
  retweet: FaRetweet,
  share: FaRegPaperPlane,
  save: FaRegBookmark,
  thumbsup: FaRegThumbsUp,
  thumbsdown: FaRegThumbsDown,
};

function ActionIcon({ actionKey, className = "" }) {
  const Icon = ACTION_ICON_MAP[actionKey];

  if (!Icon) return null;

  return <Icon className={className} aria-hidden="true" />;
}

export default ActionIcon;
