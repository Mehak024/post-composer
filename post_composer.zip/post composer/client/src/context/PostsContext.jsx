import { createContext, useState, useEffect, useCallback, useRef } from "react";

// -----------------------------------------------------------------------
// Polls GET /api/posts on an interval so the feed reflects the backend
// scheduler's work in near-real-time — a post moves from "scheduled" to
// "published" on its own, without the user doing anything, once the
// server-side scheduler (services/scheduler.js) flips it.
// -----------------------------------------------------------------------

const POLL_INTERVAL_MS = 4000;

export const PostsContext = createContext(null);

export function PostsProvider({ children }) {
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const intervalRef = useRef(null);

  const fetchPosts = useCallback(async () => {
    try {
      const response = await fetch("/api/posts");
      const data = await response.json();

      if (response.ok && data.success) {
        setPosts(data.posts);
        setError(null);
      } else {
        setError("Couldn't load posts");
      }
    } catch {
      setError("Couldn't reach the server");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPosts();
    intervalRef.current = setInterval(fetchPosts, POLL_INTERVAL_MS);
    return () => clearInterval(intervalRef.current);
  }, [fetchPosts]);

  return (
    <PostsContext.Provider value={{ posts, isLoading, error, refresh: fetchPosts }}>
      {children}
    </PostsContext.Provider>
  );
}
