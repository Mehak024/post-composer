import { createContext, useState, useMemo, useCallback, useRef } from "react";

// -----------------------------------------------------------------------
// Holds the single optional media attachment (an image or a video).
// Media upload is optional, so this stays a small, separate context
// rather than folding it into PostContext — most of the app doesn't
// care whether media exists, only MediaUpload and the draft snapshot do.
// -----------------------------------------------------------------------

export const MediaContext = createContext(null);

export function MediaProvider({ children }) {
  // { file, previewUrl, mediaType: "image" | "video", name } | null
  const [media, setMediaState] = useState(null);
  const objectUrlRef = useRef(null);

  const revokeCurrentUrl = useCallback(() => {
    if (objectUrlRef.current) {
      URL.revokeObjectURL(objectUrlRef.current);
      objectUrlRef.current = null;
    }
  }, []);

  const setMedia = useCallback(
    (file) => {
      if (!file) return;

      const mediaType = file.type.startsWith("video/") ? "video" : "image";
      const previewUrl = URL.createObjectURL(file);

      revokeCurrentUrl();
      objectUrlRef.current = previewUrl;

      setMediaState({
        file,
        previewUrl,
        mediaType,
        name: file.name,
        size: file.size,
      });
    },
    [revokeCurrentUrl]
  );

  // Used when restoring a draft that saved a persisted image preview —
  // there's no real File object in that case, just the data URL.
  const setMediaFromDraft = useCallback(
    ({ previewUrl, mediaType, name }) => {
      revokeCurrentUrl(); // this URL isn't an object URL, nothing to revoke, but keep state clean
      setMediaState({ file: null, previewUrl, mediaType, name, restored: true });
    },
    [revokeCurrentUrl]
  );

  const clearMedia = useCallback(() => {
    revokeCurrentUrl();
    setMediaState(null);
  }, [revokeCurrentUrl]);

  const value = useMemo(
    () => ({ media, setMedia, setMediaFromDraft, clearMedia }),
    [media, setMedia, setMediaFromDraft, clearMedia]
  );

  return <MediaContext.Provider value={value}>{children}</MediaContext.Provider>;
}
