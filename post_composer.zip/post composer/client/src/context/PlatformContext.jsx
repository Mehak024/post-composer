import { createContext, useMemo, useState, useCallback } from "react";
import { PLATFORMS } from "../data/platforms.js";

// -----------------------------------------------------------------------
// Holds the set of currently-selected platform ids.
// Lives at the top of the app (see App.jsx) so any descendant — the
// selector, the character counters, the live preview — can read and
// update the same selection without prop-drilling through every layer.
// -----------------------------------------------------------------------

export const PlatformContext = createContext(null);

export function PlatformProvider({ children }) {
  const [selectedIds, setSelectedIds] = useState([]);

  const togglePlatform = useCallback((id) => {
    setSelectedIds((current) =>
      current.includes(id)
        ? current.filter((existingId) => existingId !== id)
        : [...current, id]
    );
  }, []);

  const isSelected = useCallback(
    (id) => selectedIds.includes(id),
    [selectedIds]
  );

  // Wholesale replace, used by draft restore/clear — a draft snapshot
  // restores the *entire* selection at once, not one toggle at a time.
  const replaceSelection = useCallback((ids) => {
    setSelectedIds(ids ?? []);
  }, []);

  const selectedPlatforms = useMemo(
    () => PLATFORMS.filter((platform) => selectedIds.includes(platform.id)),
    [selectedIds]
  );

  const value = useMemo(
    () => ({
      selectedIds,
      selectedPlatforms,
      togglePlatform,
      isSelected,
      replaceSelection,
    }),
    [selectedIds, selectedPlatforms, togglePlatform, isSelected, replaceSelection]
  );

  return (
    <PlatformContext.Provider value={value}>
      {children}
    </PlatformContext.Provider>
  );
}
