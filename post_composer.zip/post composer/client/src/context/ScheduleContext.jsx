import { createContext, useState, useMemo, useCallback } from "react";

// -----------------------------------------------------------------------
// Holds the chosen publish date/time as a `datetime-local` string
// (e.g. "2026-07-20T14:30"). Kept as the raw input string rather than a
// Date object so the <input> stays a simple controlled component; the
// few places that need a real Date (validation) parse it on demand.
// -----------------------------------------------------------------------

export const ScheduleContext = createContext(null);

export function ScheduleProvider({ children }) {
  const [scheduledAt, setScheduledAtState] = useState("");

  const setScheduledAt = useCallback((value) => setScheduledAtState(value), []);
  const clearScheduledAt = useCallback(() => setScheduledAtState(""), []);

  const value = useMemo(
    () => ({ scheduledAt, setScheduledAt, clearScheduledAt }),
    [scheduledAt, setScheduledAt, clearScheduledAt]
  );

  return (
    <ScheduleContext.Provider value={value}>{children}</ScheduleContext.Provider>
  );
}
