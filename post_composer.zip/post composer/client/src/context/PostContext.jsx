import { createContext, useState, useMemo, useCallback } from "react";
import { getCharacterCount, getWordCount } from "../utils/textStats.js";

// -----------------------------------------------------------------------
// Holds the Title field and the single textarea's content, plus their
// derived stats. Living in context (rather than local state in
// Composer.jsx) means the per-platform counters, validation engine, and
// live preview can all read the same content without prop drilling it
// down through every layer.
// -----------------------------------------------------------------------

export const PostContext = createContext(null);

export function PostProvider({ children }) {
  const [title, setTitleState] = useState("");
  const [content, setContentState] = useState("");

  const setTitle = useCallback((value) => setTitleState(value), []);
  const clearTitle = useCallback(() => setTitleState(""), []);

  const setContent = useCallback((value) => setContentState(value), []);
  const clearContent = useCallback(() => setContentState(""), []);

  const titleCharacterCount = useMemo(() => getCharacterCount(title), [title]);
  const characterCount = useMemo(() => getCharacterCount(content), [content]);
  const wordCount = useMemo(() => getWordCount(content), [content]);

  const value = useMemo(
    () => ({
      title,
      setTitle,
      clearTitle,
      titleCharacterCount,
      content,
      setContent,
      clearContent,
      characterCount,
      wordCount,
    }),
    [
      title,
      setTitle,
      clearTitle,
      titleCharacterCount,
      content,
      setContent,
      clearContent,
      characterCount,
      wordCount,
    ]
  );

  return <PostContext.Provider value={value}>{children}</PostContext.Provider>;
}
