// Centralized so no two features accidentally collide on the same key,
// and so renaming a key means editing one line, not every call site.
export const STORAGE_KEYS = {
  DRAFT: "post-composer:draft",
  THEME: "post-composer:theme", // reserved for the theming module
};

// The Title field isn't tied to any single platform's limit — it's a
// short headline, so it gets its own flat cap.
export const TITLE_MAX_LENGTH = 100;

// Above this raw file size, we don't attempt to persist a media preview
// into localStorage as a base64 data URL — it would blow the quota (and
// video is never persisted regardless of size; see useMedia.js).
export const MEDIA_DRAFT_SIZE_LIMIT = 700 * 1024; // ~700KB
