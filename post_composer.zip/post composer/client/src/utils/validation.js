import { getCharacterStatus } from "./characterStatus.js";

// -----------------------------------------------------------------------
// Deliberately thin: all the actual threshold math already lives in
// characterStatus.js. This file's job is turning that per-platform status
// into decisions — is this platform valid, and can the whole selection
// be published — without duplicating the underlying logic.
// -----------------------------------------------------------------------

/**
 * @returns {{ platformId: string, status: "success"|"warning"|"danger", isValid: boolean }}
 */
export function validatePlatform(platform, characterCount) {
  const status = getCharacterStatus(characterCount, platform.charLimit);

  return {
    platformId: platform.id,
    status,
    isValid: status !== "danger",
  };
}

export function validateSelection(selectedPlatforms, characterCount) {
  return selectedPlatforms.map((platform) =>
    validatePlatform(platform, characterCount)
  );
}

/** Title is mandatory — just needs non-whitespace content. */
export function isTitleValid(title) {
  return title.trim().length > 0;
}

/** Description is mandatory — same rule as Title. */
export function isDescriptionValid(content) {
  return content.trim().length > 0;
}

/**
 * Schedule is now OPTIONAL — an empty value means "publish immediately"
 * and is valid. If the user DOES pick a date/time, it still can't be in
 * the past. `scheduledAt` is the raw value from a `datetime-local` input
 * (e.g. "2026-07-20T14:30").
 */
export function isScheduleValid(scheduledAt) {
  if (!scheduledAt) return true; // no schedule chosen = publish now, always valid

  const scheduledTime = new Date(scheduledAt).getTime();
  if (Number.isNaN(scheduledTime)) return false;

  return scheduledTime >= Date.now();
}

/**
 * Publishing requires: a Title, a Description, a valid schedule (empty is
 * fine — only a *past* date is rejected), at least one platform selected,
 * and every selected platform within its character limit.
 */
export function canPublish({
  title,
  content,
  scheduledAt,
  selectedPlatforms,
  characterCount,
}) {
  if (!isTitleValid(title)) return false;
  if (!isDescriptionValid(content)) return false;
  if (!isScheduleValid(scheduledAt)) return false;
  if (selectedPlatforms.length === 0) return false;

  return validateSelection(selectedPlatforms, characterCount).every(
    (result) => result.isValid
  );
}
