// -----------------------------------------------------------------------
// Thin, safe wrapper around localStorage. Every call is try/caught
// because localStorage can throw (private browsing, storage disabled,
// quota exceeded) — no component should need to know that or handle it
// itself.
// -----------------------------------------------------------------------

export function getStorageItem(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setStorageItem(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export function removeStorageItem(key) {
  try {
    localStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}
