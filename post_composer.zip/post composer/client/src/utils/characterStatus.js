// -----------------------------------------------------------------------
// Single definition of "how close to the limit is too close." The counter
// (this module) and the validation engine (next module) both import from
// here, so the color logic and the disable-publish logic can never drift
// out of sync with each other.
// -----------------------------------------------------------------------

export const CHARACTER_WARNING_RATIO = 0.9; // 90% of the limit → warning

/**
 * @returns {"success" | "warning" | "danger"}
 */
export function getCharacterStatus(characterCount, limit) {
  if (characterCount > limit) return "danger";
  if (characterCount >= limit * CHARACTER_WARNING_RATIO) return "warning";
  return "success";
}

export function getRemainingCharacters(characterCount, limit) {
  return limit - characterCount;
}

export function getUsagePercentage(characterCount, limit) {
  if (limit <= 0) return 0;
  return (characterCount / limit) * 100;
}
