// -----------------------------------------------------------------------
// Pure functions for counting text. Kept dependency-free and side-effect
// free so they're trivial to unit test and safe to call from anywhere
// (context, components, future validation utils) without duplicating logic.
// -----------------------------------------------------------------------

export function getCharacterCount(text = "") {
  return text.length;
}

export function getWordCount(text = "") {
  const trimmed = text.trim();
  if (trimmed === "") return 0;
  return trimmed.split(/\s+/).length;
}
