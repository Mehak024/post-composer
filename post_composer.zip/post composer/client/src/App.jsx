import { PlatformProvider } from "./context/PlatformContext.jsx";
import { PostProvider } from "./context/PostContext.jsx";
import { MediaProvider } from "./context/MediaContext.jsx";
import { ScheduleProvider } from "./context/ScheduleContext.jsx";
import { PostsProvider } from "./context/PostsContext.jsx";
import Composer from "./pages/Composer.jsx";

// App's job is composition, not logic: wrap the tree in the providers
// it needs (ThemeProvider in a later module) and render the current page.
function App() {
  return (
    <PlatformProvider>
      <PostProvider>
        <MediaProvider>
          <ScheduleProvider>
            <PostsProvider>
              <Composer />
            </PostsProvider>
          </ScheduleProvider>
        </MediaProvider>
      </PostProvider>
    </PlatformProvider>
  );
}

export default App;
