import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Vite config kept intentionally minimal now.
// We'll add path aliases (e.g. "@/components") once the component
// folder starts filling up, so imports stay short and refactor-safe.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    open: true,
    proxy: {
      // Forwards /api/* to the Express backend during development so the
      // frontend can just call fetch("/api/publish") with no host baked in.
      "/api": {
        target: "http://localhost:5050",
        changeOrigin: true,
      },
    },
  },
});
