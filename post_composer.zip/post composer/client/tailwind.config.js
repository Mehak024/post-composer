/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class", // toggled via a `dark` class on <html>, controlled by our ThemeContext later
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      // ---------------------------------------------------------------
      // Design tokens for the whole app. Centralizing these here means
      // every component references `bg-surface`, `text-ink`, etc.
      // instead of raw hex values scattered across files.
      // ---------------------------------------------------------------
      colors: {
        // Light mode base
        canvas: "#F6F7FB", // app background, cool ivory-slate (not warm cream)
        surface: "#FFFFFF", // cards, panels
        ink: {
          DEFAULT: "#1B1F3B", // primary text, deep indigo-navy
          muted: "#5B5F7A", // secondary text
          subtle: "#9598AD", // placeholders, disabled text
        },
        border: "#E3E5F0",

        // Dark mode base (referenced via `dark:` variants)
        "canvas-dark": "#0B0C1A",
        "surface-dark": "#14162B",
        "ink-dark": "#EDEEF7",

        // Brand / compose accent
        compose: {
          DEFAULT: "#4C5FD5",
          hover: "#3E4FC0",
          soft: "#EEF0FD", // light tint for backgrounds/badges
        },

        // Functional status colors — these are NOT decorative, they map
        // 1:1 to the validation states (ready / near-limit / exceeded)
        status: {
          success: "#2BAF7A",
          successSoft: "#E6F7EF",
          warning: "#E8A93B",
          warningSoft: "#FDF3E2",
          danger: "#E5484D",
          dangerSoft: "#FCEAEA",
        },

        // Reserved accent for the "ink ring" limit meter signature element
        limit: "#FF6B4A",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"], // headings
        body: ["'Inter'", "sans-serif"], // paragraph / UI text
        mono: ["'JetBrains Mono'", "monospace"], // character counters
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.25rem",
      },
      boxShadow: {
        soft: "0 2px 8px rgba(27, 31, 59, 0.06)",
        card: "0 4px 20px rgba(27, 31, 59, 0.08)",
      },
      keyframes: {
        "fade-in": {
          "0%": { opacity: 0, transform: "translateY(4px)" },
          "100%": { opacity: 1, transform: "translateY(0)" },
        },
      },
      animation: {
        "fade-in": "fade-in 0.2s ease-out",
      },
    },
  },
  plugins: [],
};
